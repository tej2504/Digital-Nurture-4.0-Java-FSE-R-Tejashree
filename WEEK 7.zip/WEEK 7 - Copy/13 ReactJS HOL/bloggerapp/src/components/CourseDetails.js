import React from 'react';

function CourseDetails() {
  return (
    <div>
      <h3>Angular</h3>
      <p>4/5/2021</p>
      <h3>React</h3>
      <p>6/1/2021</p>
    </div>
  );
}

export default CourseDetails;
