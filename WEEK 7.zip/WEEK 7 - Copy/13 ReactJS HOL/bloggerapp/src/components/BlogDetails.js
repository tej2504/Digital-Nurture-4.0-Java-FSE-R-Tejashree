import React from 'react';

function BlogDetails() {
  return (
    <div>
      <h3>React Learning</h3>
      <p>Stephen Biz</p>
      <p>Welcome to learning React!</p>
      <h3>Installation</h3>
      <p>You can install React from npm.</p>
    </div>
  );
}

export default BlogDetails;
